function getDados(){
  //Permite exibir uma mensagem na tela do navegador
  //alert('Bem-vindo ao site de Cadastro de Clientes!')
  
  //Permite a confirmação da mensagem por (sim/não)
  //confirm('Realmente deseja salvar os dados??!')
  
  //Permite exibir a mensagem com entrada para dados
  //prompt("Digite seu nome:")

  //Permite enviar dados para o console do navegador
  //console.log('Testando uma logica do sistema')


  //Recebe dados digitados nas caixas de texto
  //getElementById() = Pega as informações inseridas pela Identificação do objeto
  var nome = document.getElementById('nome')
  var email = document.getElementById('email')
  console.log(nome)
  /* Operadores de Comparação
      == Verifica a igualdade entre dois conteúdos
      < Menor
      > Maior
      <= Menor ou igual
      >= Maior ou igual
      != Verifica a diferença entre dois conteúdos
      === Verifica a igualdade entre dois conteúdos e se os tipos d dados são iguais
      ==! Verifica a igualdade entre dois conteúdos e se os tipos de dados são diferentes
      !== Verifica a diferença entre dois conteúdos e se os tipos de dados são iguais
      !=! Verifica a diferença entre dois conteúdos e se os tipos de dados são diferentes
      
      var valor1 = 10
      var valor2 = "10"

      if(valor 1 === valor2)

      Operadores Lógicos

      And = &&
      Or = ||
      Not = !

  */

  //Validação de entrada de dados vazios
  if(nome.value == '' || email.value == ''){
      alert("Insira os dados Porra!!!")
      if(nome.value == ''){
        nome.style.backgroundColor = '#000000'
      }
  }        
}

function setBlockNumber(tecla){
  console.log(tecla)
  if(tecla.keyCode >=48 && tecla.keyCode <=57){
    return false
  }
    


}