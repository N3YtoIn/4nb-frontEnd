//import do arquivo de dados que contém a base CEP
import { dadosCep } from "./dados.js"

//Receber o botão pesquisar no JS
const botaoPesquisar = document.getElementById('pesquisar')

//Função Tradicional
function validarDados () {
    let caixaCep = String(document.getElementById('input-cep').value)
    let status = false


    //Validação de caixa em branco
    if(caixaCep == ''){
        alert('Não foi possível realizar a busca, pois a caixa está vazia')
        status = true
    //Validação de quantidade de caracteres
    }else if(caixaCep.length != 9){
        alert('É obrigatório a entrada de 9 digitos para o cep')
        status = true
    }
    return false
}

//Função Anonima
const getDadosCep = function(){ // a função anonima não tem nome 
    console.log(dadosCep.dados[0].cep)
}

botaoPesquisar.addEventListener('click', function(){
    if(!validarDados()){ // a função ! nega o verdadeiro
            getDadosCep()

    }
    
})
